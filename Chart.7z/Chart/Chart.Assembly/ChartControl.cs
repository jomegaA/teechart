﻿using System.Windows.Forms;

namespace Chart.Assembly
{
    public partial class ChartControl : UserControl
    {
        public ChartControl()
        {
            InitializeComponent();
        }
    }
}
