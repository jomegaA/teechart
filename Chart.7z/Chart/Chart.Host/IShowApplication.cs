﻿using System.Runtime.InteropServices;

namespace Chart.Host
{
    [Guid("6E586780-92F3-4646-995B-9C4F4EB35A3F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IShowApplication
    {
        void Show();
    }
}
