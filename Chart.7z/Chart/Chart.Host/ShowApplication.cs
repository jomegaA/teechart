﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Chart.Host
{
    [Guid("FB430983-AE79-4C28-8872-40A1B3C983B6")]
    public class ShowApplication : MarshalByRefObject, IShowApplication
    {
        public void Show()
        {
            var chartAssembly = new Assembly.ChartControl();

            var form = new Form {AutoSize = true};

            form.Controls.Add(chartAssembly);
            form.ShowDialog();
        }
    }
}
